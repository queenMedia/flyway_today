import { createContext } from 'react';

const DropdownContext = createContext();

export default DropdownContext;
