import { createContext } from 'react';

const FormContext = createContext();

export default FormContext;